package com.example.minimaldm

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val INBOX = "https://www.instagram.com/direct/inbox/"

        // ---- Switches you can change ----
        private const val SECURE_SCREEN = true  // blocks screenshots + hides preview in recent apps
        private const val APP_LOCK = true       // fingerprint / face / phone PIN on every open

        // Only these hosts open inside the app; everything else goes to your browser.
        private val IN_APP_HOSTS = setOf("www.instagram.com", "instagram.com", "accountscenter.instagram.com")

        // First path segment allowed on instagram.com (plus your own username).
        // Login, 2FA and checkpoint pages live under accounts/challenge.
        private val ALLOWED_ROOTS = setOf("direct", "accounts", "challenge")

        // Runs inside the page: hides Home/Reels/Explore links and blocks taps on any
        // Instagram link that is not allowed (this catches in-page navigation).
        private const val PAGE_JS = """
(function(){
  window.__minUser = "__USER__".toLowerCase();
  if (window.__minDm) return;
  window.__minDm = true;
  var OK = ['direct','accounts','challenge'];
  var HIDE = /^\/($|reels?(\/|$)|explore(\/|$))/;
  function pathOf(a){
    try {
      var u = new URL(a.getAttribute('href'), location.href);
      if (u.hostname === 'l.instagram.com') return null;
      if (!/(^|\.)instagram\.com$/.test(u.hostname)) return null;
      return u.pathname;
    } catch(e){ return null; }
  }
  function allowed(p){
    var s = (p.split('/')[1] || '').toLowerCase();
    return OK.indexOf(s) >= 0 || (s !== '' && s === window.__minUser);
  }
  document.addEventListener('click', function(e){
    var a = e.target.closest && e.target.closest('a[href]');
    if (!a) return;
    var p = pathOf(a);
    if (p !== null && !allowed(p)) { e.preventDefault(); e.stopImmediatePropagation(); }
  }, true);
  var timer = null;
  function sweep(){
    timer = null;
    document.querySelectorAll('a[href]').forEach(function(a){
      var p = pathOf(a);
      if (p !== null && HIDE.test(p)) a.style.display = 'none';
    });
  }
  new MutationObserver(function(){ if (!timer) timer = setTimeout(sweep, 150); })
    .observe(document.documentElement, {childList: true, subtree: true});
  sweep();
})();
"""
    }

    private lateinit var web: WebView
    private val prefs by lazy { getSharedPreferences("prefs", Context.MODE_PRIVATE) }
    private var username = ""
    private var locked = true
    private var authenticating = false
    private var pickingFile = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        pickingFile = false
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (SECURE_SCREEN) {
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
        username = prefs.getString("u", "") ?: ""

        // ---- Minimal theme: black/white, follows system dark mode ----
        val dark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val bg = if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        val fg = if (dark) 0xFFFFFFFF.toInt() else 0xFF000000.toInt()
        val line = if (dark) 0xFF262626.toInt() else 0xFFDBDBDB.toInt()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }

        // ---- Locked-down WebView ----
        web = WebView(this)
        web.setBackgroundColor(bg)
        web.settings.apply {
            javaScriptEnabled = true            // Instagram needs it
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            safeBrowsingEnabled = true
            javaScriptCanOpenWindowsAutomatically = false
            mediaPlaybackRequiresUserGesture = true
            setSupportMultipleWindows(false)
        }
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(web, false)

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (inApp(u)) {
                    if (allowed(u)) return false
                    v.loadUrl(INBOX)            // reels / explore / home / etc. -> back to inbox
                    return true
                }
                if (u.host == "l.instagram.com") {   // Instagram's outbound link wrapper
                    u.getQueryParameter("u")?.let { openExternal(Uri.parse(it)) }
                    return true
                }
                openExternal(u)
                return true
            }

            // Catches in-page (single-page-app) navigation that never reloads the page
            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                val u = Uri.parse(url)
                if (inApp(u) && !allowed(u)) view.loadUrl(INBOX)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                view.evaluateJavascript(PAGE_JS.replace("__USER__", username), null)
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel()                // never continue on certificate errors
            }
        }

        // Lets you attach photos in chats
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView,
                cb: ValueCallback<Array<Uri>>,
                params: WebChromeClient.FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = cb
                pickingFile = true
                return try {
                    picker.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    pickingFile = false
                    fileCallback = null
                    false
                }
            }
        }

        // ---- Layout: web content + a two-button bottom bar ----
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }
        root.addView(web, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(match, 1))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(tab("Messages", fg) { web.loadUrl(INBOX) })
            addView(tab("Profile", fg) { openProfile() })
        }
        root.addView(bar, LinearLayout.LayoutParams(match, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        web.visibility = View.INVISIBLE
        web.loadUrl(INBOX)
    }

    // ---- App lock ----
    override fun onStart() {
        super.onStart()
        if (authenticating) return
        if (APP_LOCK && locked) {
            web.visibility = View.INVISIBLE
            authenticate()
        } else {
            unlock()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!pickingFile && !authenticating) locked = true
    }

    private fun unlock() {
        locked = false
        web.visibility = View.VISIBLE
    }

    private fun authenticate() {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (BiometricManager.from(this).canAuthenticate(auth) != BiometricManager.BIOMETRIC_SUCCESS) {
            unlock()                            // no screen lock set on the phone
            return
        }
        authenticating = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    authenticating = false
                    unlock()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    authenticating = false
                    finish()
                }
            })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle("Unlock")
                .setAllowedAuthenticators(auth)
                .build()
        )
    }

    // ---- URL policy ----
    private fun inApp(u: Uri) = u.scheme == "https" && (u.host ?: "") in IN_APP_HOSTS

    private fun allowed(u: Uri): Boolean {
        if (u.host == "accountscenter.instagram.com") return true
        val first = u.pathSegments.firstOrNull()?.lowercase() ?: return false   // "/" (home feed) is blocked
        return first in ALLOWED_ROOTS || (username.isNotEmpty() && first == username.lowercase())
    }

    private fun openExternal(u: Uri) {
        if (u.scheme == "https" || u.scheme == "http") {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, u))
            } catch (e: Exception) {
            }
        }
    }

    // ---- Profile (asks for your username once) ----
    private fun openProfile() {
        if (username.isEmpty()) askUsername() else web.loadUrl("https://www.instagram.com/$username/")
    }

    private fun askUsername() {
        val input = EditText(this).apply {
            hint = "your_username"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        AlertDialog.Builder(this)
            .setTitle("Your Instagram username")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val n = input.text.toString().trim().removePrefix("@")
                if (Regex("[A-Za-z0-9._]{1,30}").matches(n)) {
                    username = n
                    prefs.edit().putString("u", n).apply()
                    openProfile()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- Small UI helpers ----
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tab(label: String, fg: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(fg)
        textSize = 14f
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f)
        setOnClickListener { onClick() }
    }
}
