# MinimalDM – Instagram messages + profile only

## Build the APK
1. Install Android Studio (free) and open this folder (File > Open > MinimalDM).
2. Let Gradle sync (needs internet the first time).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK appears in app/build/outputs/apk/debug/app-debug.apk -> copy to phone and install
   (allow "install unknown apps" for your file manager/browser).

## Settings (top of MainActivity.kt)
- SECURE_SCREEN: true = no screenshots, hidden in recent apps
- APP_LOCK: true = fingerprint/face/PIN needed on every open
- ALLOWED_ROOTS: URL sections that may open. Add "p" if you want to open your own posts.

## Notes
- Log in only on Instagram's own page inside the app; the app never reads or stores your password.
- "Log in with Facebook" opens in your browser, so use username + password (+ 2FA).
- For personal use only. If Instagram changes its website, the hiding script may need a tweak.

## Custom name / logo (GitHub build)
Put `appname.txt` (letters, numbers, spaces only) and/or `icon.png` (square, 512x512) next to MinimalDM.zip
in the repo root; the workflow applies them automatically.
